#include "cinder/app/AppBasic.h"
#include "cinder/gl/gl.h"
#include "cinder/gl/Light.h"
#include "cinder/gl/Material.h"
#include "cinder/Perlin.h"
#include "cinder/Camera.h"
#include "cinder/params/Params.h"
#include "WorldMesh.h"

using namespace ci;
using namespace ci::app;
using namespace std;

class RenderingWorldApp : public AppBasic {
  public:
    void prepareSettings( Settings *settigs);
	void setup();
	void mouseDown( MouseEvent event );
    void keyDown( KeyEvent event );
    void keyUp( KeyEvent event);
	void update();
	void draw();
    Vec3f computeCenter(float e, float d);
    
    CameraPersp cam ;
    Vec3f eye, center, up ;
    float elevation, direction ;
    
    params::InterfaceGl parameters;
    Quatf sceneRotation ;
    
    WorldMesh world ;
    
    bool movingForward, movingBackward, turningLeft, turningRight, lookingUp, lookingDown ;
};


Vec3f RenderingWorldApp::computeCenter(float e, float d){
    float pi = atan(1)*4 ;
    float x = sin(pi/2.0f - e) * cos(d);
    float z = sin(pi/2.0f - e) * sin(d);
    float y = cos(pi/2.0f - e) ;
    return Vec3f(x,y,z);
}

void RenderingWorldApp::prepareSettings( Settings *settings ){
    settings->setWindowSize( 800, 600 );
    settings->setFrameRate( 60.0f );
}

void RenderingWorldApp::setup()
{
    parameters = params::InterfaceGl( "World", Vec2i( 225, 200 ) );
    parameters.addParam("Rotation", &sceneRotation);
    
    world = WorldMesh() ;
    world.setup();
    
    cam = CameraPersp();
    cam.setPerspective( 90.0f, getWindowAspectRatio(), 5.0f, 3000.0f );
    
    elevation = 0.0f ;
    direction = 0.0f ;
    
    eye = Vec3f(100.0f, 30.0f, 100.0f);
    center = eye + computeCenter(elevation, direction) ;
    up = Vec3f::yAxis() ;
    
    movingForward = false ;
    movingBackward = false ;
    turningLeft = false ;
    turningRight = false ;
    lookingDown = false ;
    lookingUp = false ;

}

void RenderingWorldApp::mouseDown( MouseEvent event )
{
}

void RenderingWorldApp::keyDown(cinder::app::KeyEvent event){
    if(event.getChar() == 'z'){
        movingForward = true ;
    }
    if(event.getChar() == 's'){
        movingBackward = true ;
    }
    if(event.getChar() == 'd'){
        turningRight = true ;
    }
    if(event.getChar() == 'q'){
        turningLeft = true ;
    }
    if(event.getChar() == 'a'){
        lookingUp = true ;
    }
    if(event.getChar() == 'e'){
        lookingDown = true ;
    }

}

void RenderingWorldApp::keyUp(cinder::app::KeyEvent event){
    if(event.getChar() == 'z'){
        movingForward = false ;
    }
    if(event.getChar() == 's'){
        movingBackward = false ;
    }
    if(event.getChar() == 'd'){
        turningRight = false ;
    }
    if(event.getChar() == 'q'){
        turningLeft = false ;
    }
    if(event.getChar() == 'a'){
        lookingUp = false ;
    }
    if(event.getChar() == 'e'){
        lookingDown = false ;
    }
}

void RenderingWorldApp::update()
{
    float pi = atan(1) * 4 ;
    if(movingForward){
        Vec3f movementDirection = center - eye ;
        movementDirection.normalize();
        eye += movementDirection ;
    }
    if(movingBackward){
        Vec3f movementDirection = center - eye ;
        movementDirection.normalize();
        eye -= movementDirection ;
    }
    if(turningLeft){
        direction -= 0.01f ;
    }
    if(turningRight){
        direction += 0.01f ;
    }
    if(lookingUp){
        elevation = min(pi/2, elevation + 0.01f);
    }
    if(lookingDown){
        elevation = max(-pi/2, elevation - 0.01f);
    }

    center = eye + computeCenter(elevation, direction);
    cam.lookAt( eye, center, up );
    gl::setMatrices( cam );
    gl::rotate( sceneRotation) ;
    world.update();
}

void RenderingWorldApp::draw()
{
    gl::clear(Color(1.0f, 1.0f, 1.0f));
    gl::enableDepthWrite();
	gl::enableDepthRead();
	gl::enableAlphaBlending();

	world.draw();
    parameters.draw();
//    gl::drawSphere(Vec3f(0.0f, 0.0f, 0.0f), 5.0f);
}

CINDER_APP_BASIC( RenderingWorldApp, RendererGl )
